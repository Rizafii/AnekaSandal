<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cart;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Products;
use App\Models\ProductVariant;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class CheckoutController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        $items = collect();
        $total = 0;

        // Check if it's buy now or from cart
        if (session('buy_now')) {
            $buyNowData = session('buy_now');
            $product = Products::with(['images', 'variants'])->findOrFail($buyNowData['product_id']);
            $variant = null;

            if ($buyNowData['variant_id']) {
                $variant = ProductVariant::findOrFail($buyNowData['variant_id']);
            }

            $price = $product->price + ($variant ? $variant->additional_price : 0);
            $subtotal = $price * $buyNowData['quantity'];

            $items->push((object) [
                'id' => 'buy_now',
                'product' => $product,
                'variant' => $variant,
                'quantity' => $buyNowData['quantity'],
                'price' => $price,
                'subtotal' => $subtotal
            ]);

            $total = $subtotal;
        } else {
            // Get selected cart items
            $selectedIds = $request->get('selected_items', []);
            if (empty($selectedIds)) {
                return redirect()->route('cart.index')->with('error', 'Pilih item yang ingin di-checkout');
            }

            $cartItems = Cart::with(['product.images', 'variant'])
                ->whereIn('id', $selectedIds)
                ->where('user_id', Auth::id())
                ->get();

            foreach ($cartItems as $item) {
                $items->push($item);
                $total += $item->subtotal;
            }
        }

        $shippingCost = 10000; // Default shipping cost
        $finalAmount = $total + $shippingCost;

        return view('checkout.index', compact('items', 'total', 'shippingCost', 'finalAmount'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'shipping_name' => 'required|string|max:100',
            'shipping_phone' => 'required|string|max:20',
            'shipping_address' => 'required|string',
            'shipping_city' => 'required|string|max:100',
            'shipping_postal_code' => 'required|string|max:10',
        ]);

        DB::beginTransaction();
        try {
            $items = collect();
            $total = 0;

            // Get items again (same logic as index)
            if (session('buy_now')) {
                $buyNowData = session('buy_now');
                $product = Products::findOrFail($buyNowData['product_id']);
                $variant = null;

                if ($buyNowData['variant_id']) {
                    $variant = ProductVariant::findOrFail($buyNowData['variant_id']);
                }

                $price = $product->price + ($variant ? $variant->additional_price : 0);
                $subtotal = $price * $buyNowData['quantity'];

                $items->push((object) [
                    'product' => $product,
                    'variant' => $variant,
                    'quantity' => $buyNowData['quantity'],
                    'price' => $price,
                    'subtotal' => $subtotal
                ]);

                $total = $subtotal;
            } else {
                $selectedIds = $request->get('selected_items', []);
                $cartItems = Cart::with(['product', 'variant'])
                    ->whereIn('id', $selectedIds)
                    ->where('user_id', Auth::id())
                    ->get();

                foreach ($cartItems as $item) {
                    $items->push($item);
                    $total += $item->subtotal;
                }
            }

            $shippingCost = 10000;
            $finalAmount = $total + $shippingCost;

            // Create order
            $order = Order::create([
                'user_id' => Auth::id(),
                'status' => Order::STATUS_MENUNGGU_PEMBAYARAN,
                'total_amount' => $total,
                'shipping_cost' => $shippingCost,
                'final_amount' => $finalAmount,
                'shipping_name' => $request->shipping_name,
                'shipping_phone' => $request->shipping_phone,
                'shipping_address' => $request->shipping_address,
                'shipping_city' => $request->shipping_city,
                'shipping_postal_code' => $request->shipping_postal_code,
                'payment_status' => Order::PAYMENT_STATUS_BELUM_BAYAR
            ]);

            // Create order items
            foreach ($items as $item) {
                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $item->product->id,
                    'variant_id' => $item->variant ? $item->variant->id : null,
                    'product_name' => $item->product->name,
                    'variant_info' => $item->variant ? "{$item->variant->size} - {$item->variant->color}" : null,
                    'price' => $item->price,
                    'quantity' => $item->quantity,
                    'subtotal' => $item->subtotal
                ]);

                // Reduce stock
                if ($item->variant) {
                    $item->variant->decrement('stock', $item->quantity);
                }
            }

            // Log status
            $order->addStatusLog(Order::STATUS_MENUNGGU_PEMBAYARAN, 'Pesanan dibuat');

            // Clear cart if not buy now
            if (!session('buy_now')) {
                $selectedIds = $request->get('selected_items', []);
                Cart::whereIn('id', $selectedIds)->where('user_id', Auth::id())->delete();
            } else {
                session()->forget('buy_now');
            }

            DB::commit();

            return redirect()->route('checkout.payment', $order->id);

        } catch (\Exception $e) {
            DB::rollback();
            return back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage());
        }
    }

    public function payment(Order $order)
    {
        $this->authorize('view', $order);

        return view('checkout.payment', compact('order'));
    }

    public function uploadPayment(Request $request, Order $order)
    {
        $this->authorize('update', $order);

        $request->validate([
            'payment_proof' => 'required|image|mimes:jpeg,png,jpg|max:2048'
        ]);

        if ($request->hasFile('payment_proof')) {
            $file = $request->file('payment_proof');
            $filename = 'payment_' . $order->id . '_' . time() . '.' . $file->getClientOriginalExtension();
            $path = $file->storeAs('payment_proofs', $filename, 'public');

            $order->update([
                'payment_proof' => $path,
                'payment_status' => Order::PAYMENT_STATUS_MENUNGGU_KONFIRMASI
            ]);

            $order->addStatusLog(Order::PAYMENT_STATUS_MENUNGGU_KONFIRMASI, 'Bukti pembayaran diunggah');

            return redirect()->route('orders.show', $order->id)->with('success', 'Bukti pembayaran berhasil diunggah. Silakan tunggu konfirmasi admin.');
        }

        return back()->with('error', 'Gagal mengunggah bukti pembayaran');
    }
}
