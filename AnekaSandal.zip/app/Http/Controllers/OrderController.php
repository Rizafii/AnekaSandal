<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $orders = Order::with(['items.product', 'statusLogs'])
            ->where('user_id', Auth::id())
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return view('orders.index', compact('orders'));
    }

    public function show(Order $order)
    {
        $this->authorize('view', $order);

        $order->load(['items.product.images', 'items.variant', 'statusLogs.changedBy']);

        return view('orders.show', compact('order'));
    }

    public function confirmReceived(Request $request, Order $order)
    {
        $this->authorize('update', $order);

        $request->validate([
            'delivery_proof' => 'required|image|mimes:jpeg,png,jpg|max:2048'
        ]);

        if ($order->status !== Order::STATUS_SEDANG_DIKIRIM) {
            return back()->with('error', 'Status pesanan tidak valid untuk konfirmasi penerimaan');
        }

        if ($request->hasFile('delivery_proof')) {
            $file = $request->file('delivery_proof');
            $filename = 'delivery_' . $order->id . '_' . time() . '.' . $file->getClientOriginalExtension();
            $path = $file->storeAs('delivery_proofs', $filename, 'public');

            $order->update([
                'status' => Order::STATUS_SELESAI,
                'delivered_at' => now(),
                'notes' => ($order->notes ? $order->notes . "\n" : '') . 'Bukti penerimaan: ' . $path
            ]);

            $order->addStatusLog(Order::STATUS_SELESAI, 'Pesanan diterima oleh customer', Auth::id());

            return redirect()->route('orders.show', $order->id)->with('success', 'Terima kasih! Pesanan telah dikonfirmasi diterima.');
        }

        return back()->with('error', 'Gagal mengunggah bukti penerimaan');
    }
}
