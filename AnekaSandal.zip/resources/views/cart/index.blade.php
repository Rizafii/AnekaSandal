@extends('app')

@section('title', 'Keranjang Belanja')

@section('content')
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold text-gray-800 mb-8">Keranjang Belanja</h1>

        @if($cartItems->count() > 0)
            <form action="{{ route('checkout.index') }}" method="GET" id="checkoutForm">
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="p-6">
                        <div class="flex items-center mb-4">
                            <input type="checkbox" id="selectAll" class="mr-3">
                            <label for="selectAll" class="text-gray-700 font-medium">Pilih Semua</label>
                        </div>

                        <div class="space-y-6">
                            @foreach($cartItems as $item)
                                <div class="flex items-center bg-gray-50 p-4 rounded-lg">
                                    <input type="checkbox" name="selected_items[]" value="{{ $item->id }}"
                                        class="item-checkbox mr-4">

                                    <div class="flex-shrink-0 w-20 h-20">
                                        <img src="{{ $item->product->images->first()?->url ?? 'https://via.placeholder.com/80x80' }}"
                                            alt="{{ $item->product->name }}" class="w-full h-full object-cover rounded-md">
                                    </div>

                                    <div class="flex-grow ml-4">
                                        <h3 class="font-semibold text-gray-800">{{ $item->product->name }}</h3>
                                        @if($item->variant)
                                            <p class="text-sm text-gray-600">
                                                Ukuran: {{ $item->variant->size }}
                                                @if($item->variant->color)
                                                    | Warna: {{ $item->variant->color }}
                                                @endif
                                            </p>
                                        @endif
                                        <p class="text-lg font-bold text-blue-600">
                                            Rp
                                            {{ number_format($item->product->price + ($item->variant ? $item->variant->additional_price : 0), 0, ',', '.') }}
                                        </p>
                                    </div>

                                    <div class="flex items-center space-x-3">
                                        <form action="{{ route('cart.update', $item->id) }}" method="POST"
                                            class="flex items-center">
                                            @csrf
                                            @method('PUT')
                                            <button type="button" class="bg-gray-200 px-2 py-1 rounded-l-md"
                                                onclick="decreaseQuantity(this)">-</button>
                                            <input type="number" name="quantity" value="{{ $item->quantity }}" min="1"
                                                class="w-16 text-center border-gray-200 border-t border-b py-1"
                                                onchange="this.form.submit()">
                                            <button type="button" class="bg-gray-200 px-2 py-1 rounded-r-md"
                                                onclick="increaseQuantity(this)">+</button>
                                        </form>

                                        <div class="text-right">
                                            <p class="font-bold text-gray-800">
                                                Rp {{ number_format($item->subtotal, 0, ',', '.') }}
                                            </p>
                                        </div>

                                        <form action="{{ route('cart.destroy', $item->id) }}" method="POST"
                                            onsubmit="return confirm('Hapus item ini dari keranjang?')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="text-red-500 hover:text-red-700 ml-4">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                        d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16">
                                                    </path>
                                                </svg>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>

                    <div class="bg-gray-100 px-6 py-4">
                        <div class="flex justify-between items-center">
                            <div>
                                <p class="text-lg">Total: <span class="font-bold text-blue-600" id="selectedTotal">Rp 0</span>
                                </p>
                                <p class="text-sm text-gray-600"><span id="selectedCount">0</span> item dipilih</p>
                            </div>
                            <button type="submit" id="checkoutBtn" disabled
                                class="bg-blue-600 text-white px-8 py-3 rounded-lg font-medium hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed">
                                Checkout
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        @else
            <div class="text-center py-16">
                <svg class="mx-auto h-24 w-24 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17M17 13v4a2 2 0 01-2 2H9a2 2 0 01-2-2v-4.01">
                    </path>
                </svg>
                <h3 class="mt-4 text-lg font-medium text-gray-900">Keranjang kosong</h3>
                <p class="mt-2 text-gray-500">Belum ada produk di keranjang Anda</p>
                <div class="mt-6">
                    <a href="{{ route('products') }}"
                        class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                        Mulai Belanja
                    </a>
                </div>
            </div>
        @endif
    </div>

    @push('scripts')
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                const selectAllCheckbox = document.getElementById('selectAll');
                const itemCheckboxes = document.querySelectorAll('.item-checkbox');
                const checkoutBtn = document.getElementById('checkoutBtn');
                const selectedTotalElement = document.getElementById('selectedTotal');
                const selectedCountElement = document.getElementById('selectedCount');

                // Cart item data
                const cartItems = @json($cartItems->map(function ($item) {
                    return [
                        'id' => $item->id,
                        'subtotal' => $item->subtotal
                    ];
                }));

                function updateCheckoutButton() {
                    const checkedItems = document.querySelectorAll('.item-checkbox:checked');
                    const isAnySelected = checkedItems.length > 0;

                    checkoutBtn.disabled = !isAnySelected;

                    // Calculate total
                    let total = 0;
                    checkedItems.forEach(checkbox => {
                        const itemId = parseInt(checkbox.value);
                        const item = cartItems.find(item => item.id === itemId);
                        if (item) {
                            total += item.subtotal;
                        }
                    });

                    selectedTotalElement.textContent = 'Rp ' + total.toLocaleString('id-ID');
                    selectedCountElement.textContent = checkedItems.length;
                }

                // Select all functionality
                selectAllCheckbox.addEventListener('change', function () {
                    itemCheckboxes.forEach(checkbox => {
                        checkbox.checked = this.checked;
                    });
                    updateCheckoutButton();
                });

                // Individual checkbox functionality
                itemCheckboxes.forEach(checkbox => {
                    checkbox.addEventListener('change', function () {
                        const allChecked = Array.from(itemCheckboxes).every(cb => cb.checked);
                        const anyChecked = Array.from(itemCheckboxes).some(cb => cb.checked);

                        selectAllCheckbox.checked = allChecked;
                        selectAllCheckbox.indeterminate = anyChecked && !allChecked;

                        updateCheckoutButton();
                    });
                });

                // Initial state
                updateCheckoutButton();
            });

            function increaseQuantity(button) {
                const input = button.previousElementSibling;
                input.value = parseInt(input.value) + 1;
                input.form.submit();
            }

            function decreaseQuantity(button) {
                const input = button.nextElementSibling;
                if (parseInt(input.value) > 1) {
                    input.value = parseInt(input.value) - 1;
                    input.form.submit();
                }
            }
        </script>
    @endpush
@endsection