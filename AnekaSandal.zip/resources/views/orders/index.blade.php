@extends('app')

@section('title', 'Pesanan Saya')

    @section('content')
        <div class="container mx-auto px-4 py-8">
            <h1 class="text-3xl font-bold text-gray-800 mb-8">Pesanan Saya</h1>

            @if($orders->count() > 0)
                <div class="space-y-6">
                    @foreach($orders as $order)
                        <div class="bg-white rounded-lg shadow-md overflow-hidden">
                            <!-- Order Header -->
                            <div class="bg-gray-50 px-6 py-4 border-b border-gray-200">
                                <div class="flex justify-between items-center">
                                    <div>
                                        <h3 class="text-lg font-semibold text-gray-900">{{ $order->order_number }}</h3>
                                        <p class="text-sm text-gray-600">{{ $order->created_at->format('d M Y, H:i') }}</p>
                                    </div>
                                    <div class="text-right">
                                        @php
                                            $statusClass = match ($order->status) {
                                                'menunggu_pembayaran' => 'bg-yellow-100 text-yellow-800',
                                                'sedang_dikirm' => 'bg-blue-100 text-blue-800',
                                                'selesai' => 'bg-green-100 text-green-800',
                                                'dibatalkan' => 'bg-red-100 text-red-800',
                                                default => 'bg-gray-100 text-gray-800'
                                            };

                                            $paymentStatusClass = match ($order->payment_status) {
                                                'belum_bayar' => 'bg-gray-100 text-gray-800',
                                                'menunggu_konfirmasi' => 'bg-orange-100 text-orange-800',
                                                'terkonfirmasi' => 'bg-green-100 text-green-800',
                                                'ditolak' => 'bg-red-100 text-red-800',
                                                default => 'bg-gray-100 text-gray-800'
                                            };
                                        @endphp
                                        <span class="inline-flex px-3 py-1 text-sm font-semibold rounded-full {{ $statusClass }} mb-2">
                                            {{ ucfirst(str_replace('_', ' ', $order->status)) }}
                                        </span>
                                        <br>
                                        <span
                                            class="inline-flex px-3 py-1 text-sm font-semibold rounded-full {{ $paymentStatusClass }}">
                                            {{ ucfirst(str_replace('_', ' ', $order->payment_status)) }}
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <!-- Order Items -->
                            <div class="px-6 py-4">
                                <div class="space-y-4">
                                    @foreach($order->items as $item)
                                        <div class="flex items-center">
                                            <div class="flex-shrink-0 w-16 h-16">
                                                @if($item->product && $item->product->images->count() > 0)
                                                    <img src="{{ $item->product->images->first()->url }}" alt="{{ $item->product_name }}"
                                                        class="w-16 h-16 object-cover rounded-lg">
                                                @else
                                                    <div class="w-16 h-16 bg-gray-200 rounded-lg flex items-center justify-center">
                                                        <svg class="w-8 h-8 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                                                            <path fill-rule="evenodd"
                                                                d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z"
                                                                clip-rule="evenodd"></path>
                                                        </svg>
                                                    </div>
                                                @endif
                                            </div>
                                            <div class="ml-4 flex-1">
                                                <h4 class="text-lg font-medium text-gray-900">{{ $item->product_name }}</h4>
                                                @if($item->variant_info)
                                                    <p class="text-sm text-gray-600">{{ $item->variant_info }}</p>
                                                @endif
                                                <p class="text-sm text-gray-600">{{ $item->quantity }}x Rp {{ number_format($item->price) }}
                                                </p>
                                            </div>
                                            <div class="text-right">
                                                <p class="text-lg font-semibold text-gray-900">Rp {{ number_format($item->subtotal) }}</p>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            </div>

                            <!-- Order Footer -->
                            <div class="bg-gray-50 px-6 py-4 border-t border-gray-200">
                                <div class="flex justify-between items-center">
                                    <div class="text-sm text-gray-600">
                                        <p>{{ $order->items->count() }} item • Total: <span class="font-semibold text-gray-900">Rp
                                                {{ number_format($order->final_amount) }}</span></p>
                                    </div>
                                    <div class="flex space-x-3">
                                        <a href="{{ route('orders.show', $order->id) }}"
                                            class="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700">
                                            Detail
                                        </a>

                                        @if($order->payment_status === 'belum_bayar')
                                            <a href="{{ route('checkout.payment', $order->id) }}"
                                                class="bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-green-700">
                                                Bayar Sekarang
                                            </a>
                                        @endif

                                        @if($order->status === 'sedang_dikirm' && $order->shipped_at)
                                            <button onclick="openConfirmModal({{ $order->id }})"
                                                class="bg-purple-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-purple-700">
                                                Konfirmasi Terima
                                            </button>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>

                <!-- Pagination -->
                @if($orders->hasPages())
                    <div class="mt-8">
                        {{ $orders->links() }}
                    </div>
                @endif
            @else
                <div class="text-center py-16">
                    <svg class="mx-auto h-24 w-24 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
                    </svg>
                    <h3 class="text-xl font-medium text-gray-900 mt-4">Belum ada pesanan</h3>
                    <p class="text-gray-600 mt-2">Mulai berbelanja untuk melihat pesanan Anda di sini</p>
                    <a href="{{ route('home') }}"
                        class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 mt-6">
                        Mulai Belanja
                    </a>
                </div>
            @endif
        </div>

        <!-- Confirm Receipt Modal -->
        <div id="confirmModal" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog"
            aria-modal="true">
            <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
                <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
                <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
                <div
                    class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
                    <form id="confirmForm" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                            <div class="sm:flex sm:items-start">
                                <div
                                    class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-green-100 sm:mx-0 sm:h-10 sm:w-10">
                                    <svg class="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M5 13l4 4L19 7" />
                                    </svg>
                                </div>
                                <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                                    <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                        Konfirmasi Penerimaan Barang
                                    </h3>
                                    <div class="mt-4">
                                        <label for="delivery_proof" class="block text-sm font-medium text-gray-700 mb-2">Upload
                                            Foto Bukti Penerimaan</label>
                                        <input type="file" name="delivery_proof" id="delivery_proof" accept="image/*" required
                                            class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 focus:outline-none">
                                        <p class="text-xs text-gray-500 mt-1">Upload foto Anda dengan barang yang diterima</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                            <button type="submit"
                                class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-green-600 text-base font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 sm:ml-3 sm:w-auto sm:text-sm">
                                Konfirmasi Terima
                            </button>
                            <button type="button" onclick="closeConfirmModal()"
                                class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                                Batal
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    @endsection

    @push('scripts')
        <script>
            function openConfirmModal(orderId) {
                document.getElementById('confirmForm').action = `/orders/${orderId}/confirm-received`;
                document.getElementById('confirmModal').classList.remove('hidden');
            }

            function closeConfirmModal() {
                document.getElementById('confirmModal').classList.add('hidden');
            }

            // Close modal when clicking outside
            document.getElementById('confirmModal').addEventListener('click', function (e) {
                if (e.target === this) {
                    closeConfirmModal();
                }
            });
        </script>
    @endpush
@endsection