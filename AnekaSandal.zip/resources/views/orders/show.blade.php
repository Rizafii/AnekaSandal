@extends('app')

@section('title', 'Detail Pesanan #' . $order->order_number)

    @section('content')
        <div class="container mx-auto px-4 py-8">
            <div class="flex items-center mb-6">
                <a href="{{ route('orders.index') }}" class="text-blue-600 hover:text-blue-800 mr-4">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                    </svg>
                </a>
                <h1 class="text-3xl font-bold text-gray-800">Detail Pesanan #{{ $order->order_number }}</h1>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <!-- Main Content -->
                <div class="lg:col-span-2">
                    <!-- Order Status -->
                    <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                        <h2 class="text-xl font-semibold mb-4">Status Pesanan</h2>

                        <!-- Status Progress -->
                        <div class="flex items-center justify-between mb-6">
                            @php
                                $statusClass = match ($order->status) {
                                    'menunggu_pembayaran' => 'bg-yellow-100 text-yellow-800',
                                    'sedang_dikirm' => 'bg-blue-100 text-blue-800',
                                    'selesai' => 'bg-green-100 text-green-800',
                                    'dibatalkan' => 'bg-red-100 text-red-800',
                                    default => 'bg-gray-100 text-gray-800'
                                };

                                $paymentStatusClass = match ($order->payment_status) {
                                    'belum_bayar' => 'bg-gray-100 text-gray-800',
                                    'menunggu_konfirmasi' => 'bg-orange-100 text-orange-800',
                                    'terkonfirmasi' => 'bg-green-100 text-green-800',
                                    'ditolak' => 'bg-red-100 text-red-800',
                                    default => 'bg-gray-100 text-gray-800'
                                };
                            @endphp
                            <span class="inline-flex px-4 py-2 text-sm font-semibold rounded-full {{ $statusClass }}">
                                {{ ucfirst(str_replace('_', ' ', $order->status)) }}
                            </span>
                            <span class="inline-flex px-4 py-2 text-sm font-semibold rounded-full {{ $paymentStatusClass }}">
                                {{ ucfirst(str_replace('_', ' ', $order->payment_status)) }}
                            </span>
                        </div>

                        <!-- Action Buttons -->
                        <div class="flex space-x-3">
                            @if($order->payment_status === 'belum_bayar')
                                <a href="{{ route('checkout.payment', $order->id) }}"
                                    class="bg-green-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-green-700">
                                    💳 Bayar Sekarang
                                </a>
                            @endif

                            @if($order->status === 'sedang_dikirm' && $order->shipped_at)
                                <button onclick="openConfirmModal()"
                                    class="bg-purple-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-purple-700">
                                    📦 Konfirmasi Terima Barang
                                </button>
                            @endif
                        </div>

                        <!-- Status Information -->
                        <div class="mt-6 text-sm text-gray-600">
                            @if($order->payment_status === 'menunggu_konfirmasi')
                                <div class="bg-orange-50 border border-orange-200 rounded-lg p-4">
                                    <p class="text-orange-800">⏳ Bukti pembayaran Anda sedang diverifikasi oleh admin. Mohon tunggu
                                        konfirmasi.</p>
                                </div>
                            @elseif($order->payment_status === 'ditolak')
                                <div class="bg-red-50 border border-red-200 rounded-lg p-4">
                                    <p class="text-red-800">❌ Pembayaran ditolak. Silakan upload bukti pembayaran yang valid.</p>
                                </div>
                            @elseif($order->status === 'sedang_dikirm' && $order->shipped_at)
                                <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                                    <p class="text-blue-800">🚚 Pesanan Anda sedang dalam perjalanan.</p>
                                    @if($order->tracking_number)
                                        <p class="text-blue-800 mt-1"><strong>Nomor Resi:</strong> {{ $order->tracking_number }}</p>
                                    @endif
                                    <p class="text-blue-800 mt-1"><strong>Tanggal Pengiriman:</strong>
                                        {{ $order->shipped_at->format('d M Y, H:i') }}</p>
                                </div>
                            @elseif($order->status === 'selesai')
                                <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                                    <p class="text-green-800">✅ Pesanan selesai. Terima kasih telah berbelanja!</p>
                                    @if($order->delivered_at)
                                        <p class="text-green-800 mt-1"><strong>Diterima pada:</strong>
                                            {{ $order->delivered_at->format('d M Y, H:i') }}</p>
                                    @endif
                                </div>
                            @endif
                        </div>
                    </div>

                    <!-- Order Items -->
                    <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                        <h2 class="text-xl font-semibold mb-4">Item Pesanan</h2>

                        <div class="space-y-4">
                            @foreach($order->items as $item)
                                <div class="flex items-center border-b border-gray-200 pb-4 last:border-b-0">
                                    <div class="flex-shrink-0 w-20 h-20">
                                        @if($item->product && $item->product->images->count() > 0)
                                            <img src="{{ $item->product->images->first()->url }}" alt="{{ $item->product_name }}"
                                                class="w-20 h-20 object-cover rounded-lg">
                                        @else
                                            <div class="w-20 h-20 bg-gray-200 rounded-lg flex items-center justify-center">
                                                <svg class="w-10 h-10 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd"
                                                        d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z"
                                                        clip-rule="evenodd"></path>
                                                </svg>
                                            </div>
                                        @endif
                                    </div>
                                    <div class="ml-6 flex-1">
                                        <h3 class="text-lg font-medium text-gray-900">{{ $item->product_name }}</h3>
                                        @if($item->variant_info)
                                            <p class="text-sm text-gray-600 mt-1">{{ $item->variant_info }}</p>
                                        @endif
                                        <div class="flex items-center justify-between mt-2">
                                            <p class="text-sm text-gray-600">Rp {{ number_format($item->price) }} x
                                                {{ $item->quantity }}</p>
                                            <p class="text-lg font-semibold text-gray-900">Rp {{ number_format($item->subtotal) }}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>

                        <!-- Order Total -->
                        <div class="mt-6 pt-4 border-t border-gray-200">
                            <div class="space-y-2">
                                <div class="flex justify-between text-sm">
                                    <span class="text-gray-600">Subtotal</span>
                                    <span class="text-gray-900">Rp {{ number_format($order->total_amount) }}</span>
                                </div>
                                <div class="flex justify-between text-sm">
                                    <span class="text-gray-600">Ongkos Kirim</span>
                                    <span class="text-gray-900">Rp {{ number_format($order->shipping_cost) }}</span>
                                </div>
                                <div class="flex justify-between text-lg font-semibold pt-2 border-t border-gray-200">
                                    <span>Total</span>
                                    <span>Rp {{ number_format($order->final_amount) }}</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Status Logs -->
                    @if($order->statusLogs->count() > 0)
                        <div class="bg-white rounded-lg shadow-md p-6">
                            <h2 class="text-xl font-semibold mb-4">Riwayat Status</h2>
                            <div class="space-y-4">
                                @foreach($order->statusLogs->sortByDesc('created_at') as $log)
                                    <div class="flex items-start">
                                        <div class="flex-shrink-0 w-3 h-3 bg-blue-500 rounded-full mt-2"></div>
                                        <div class="ml-4">
                                            <p class="text-sm font-medium text-gray-900">
                                                {{ ucfirst(str_replace('_', ' ', $log->status)) }}</p>
                                            @if($log->notes)
                                                <p class="text-sm text-gray-600 mt-1">{{ $log->notes }}</p>
                                            @endif
                                            <p class="text-xs text-gray-500 mt-1">{{ $log->created_at->format('d M Y, H:i') }}</p>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    @endif
                </div>

                <!-- Sidebar -->
                <div class="lg:col-span-1">
                    <!-- Order Info -->
                    <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                        <h3 class="text-lg font-semibold mb-4">Informasi Pesanan</h3>
                        <div class="space-y-3 text-sm">
                            <div>
                                <label class="font-medium text-gray-700">Nomor Pesanan:</label>
                                <p class="text-gray-900">{{ $order->order_number }}</p>
                            </div>
                            <div>
                                <label class="font-medium text-gray-700">Tanggal Pesanan:</label>
                                <p class="text-gray-900">{{ $order->created_at->format('d M Y, H:i') }}</p>
                            </div>
                            @if($order->notes)
                                <div>
                                    <label class="font-medium text-gray-700">Catatan:</label>
                                    <p class="text-gray-900">{{ $order->notes }}</p>
                                </div>
                            @endif
                        </div>
                    </div>

                    <!-- Shipping Info -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-lg font-semibold mb-4">Informasi Pengiriman</h3>
                        <div class="space-y-3 text-sm">
                            <div>
                                <label class="font-medium text-gray-700">Nama Penerima:</label>
                                <p class="text-gray-900">{{ $order->shipping_name }}</p>
                            </div>
                            <div>
                                <label class="font-medium text-gray-700">Telepon:</label>
                                <p class="text-gray-900">{{ $order->shipping_phone }}</p>
                            </div>
                            <div>
                                <label class="font-medium text-gray-700">Alamat:</label>
                                <p class="text-gray-900">{{ $order->shipping_address }}</p>
                            </div>
                            @if($order->shipping_city)
                                <div>
                                    <label class="font-medium text-gray-700">Kota:</label>
                                    <p class="text-gray-900">{{ $order->shipping_city }}</p>
                                </div>
                            @endif
                            @if($order->shipping_postal_code)
                                <div>
                                    <label class="font-medium text-gray-700">Kode Pos:</label>
                                    <p class="text-gray-900">{{ $order->shipping_postal_code }}</p>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Confirm Receipt Modal -->
        <div id="confirmModal" class="fixed inset-0 z-50 hidden overflow-y-auto" aria-labelledby="modal-title" role="dialog"
            aria-modal="true">
            <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
                <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true"></div>
                <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
                <div
                    class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
                    <form action="{{ route('orders.confirm.received', $order->id) }}" method="POST"
                        enctype="multipart/form-data">
                        @csrf
                        <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                            <div class="sm:flex sm:items-start">
                                <div
                                    class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-green-100 sm:mx-0 sm:h-10 sm:w-10">
                                    <svg class="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M5 13l4 4L19 7" />
                                    </svg>
                                </div>
                                <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                                    <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                                        Konfirmasi Penerimaan Barang
                                    </h3>
                                    <div class="mt-4">
                                        <label for="delivery_proof" class="block text-sm font-medium text-gray-700 mb-2">Upload
                                            Foto Bukti Penerimaan</label>
                                        <input type="file" name="delivery_proof" id="delivery_proof" accept="image/*" required
                                            class="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 focus:outline-none">
                                        <p class="text-xs text-gray-500 mt-1">Upload foto Anda dengan barang yang diterima
                                            sebagai bukti bahwa pesanan telah diterima dengan baik</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                            <button type="submit"
                                class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-green-600 text-base font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 sm:ml-3 sm:w-auto sm:text-sm">
                                Konfirmasi Terima
                            </button>
                            <button type="button" onclick="closeConfirmModal()"
                                class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                                Batal
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    @endsection

    @push('scripts')
        <script>
            function openConfirmModal() {
                document.getElementById('confirmModal').classList.remove('hidden');
            }

            function closeConfirmModal() {
                document.getElementById('confirmModal').classList.add('hidden');
            }

            // Close modal when clicking outside
            document.getElementById('confirmModal').addEventListener('click', function (e) {
                if (e.target === this) {
                    closeConfirmModal();
                }
            });
        </script>
    @endpush
@endsection