@extends('app')

@section('title', 'Keranjang Belanja')

@section('content')
    <livewire:cart-index />
@endsection
