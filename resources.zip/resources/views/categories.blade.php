@extends('app')

@section('content')
    @livewire('category-page')
@endsection
