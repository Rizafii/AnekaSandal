@extends('app')

@section('content')
    @livewire('products-page')
@endsection